//
//  ViewController.swift
//  Taboola SDK Swift Sample
//
//  Created by Roman Slyepko on 3/5/19.
//  Copyright © 2019 Taboola LTD. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

}

